SWEP.PrintName = "Doritos"
SWEP.Category = "Chips"
SWEP.ViewModel = Model("models/chipbags/doritos/doritos.mdl")
SWEP.WorldModel = Model("models/chipbags/doritos/doritos.mdl")
SWEP.Spawnable = true

SWEP.Author = "JaxonStormbeard"
SWEP.Instructions = "Yumm just wish it would heal me more"

SWEP.Primary.Ammo = 0
SWEP.Secondary.Ammo = 0

list.Set("ContentCategoryIcons", "Chips", "icon16/chips.png")

if CLIENT then
    SWEP.WepSelectIcon = surface.GetTextureID("vgui/hud/chips_inv")
end




function SWEP:GetViewModelPosition(pos, ang)

local forward = 15
local right = 12
local up = -9

pos = pos + ang:Forward() * forward + ang:Right() * right + ang:Up() * up
ang:RotateAroundAxis(ang:Up(), 140)
return pos, ang

end

if CLIENT then
    SWEP.ClientWM = nil

    function SWEP:DrawWorldModel()
        local owner = self:GetOwner()
        
        if IsValid(owner) then
            if not IsValid(self.ClientWM) then
                self.ClientWM = ClientsideModel("models/chipbags/doritos/doritos.mdl", RENDERGROUP_OPAQUE)
                self.ClientWM:SetNoDraw(true)
            end

            local boneIndex = owner:LookupBone("ValveBiped.Bip01_R_Hand")
            if boneIndex then
                local matrix = owner:GetBoneMatrix(boneIndex)
                if matrix then
                    local p = matrix:GetTranslation()
                    local a = matrix:GetAngles()

                    a:RotateAroundAxis(a:Forward(), 180) 
                    a:RotateAroundAxis(a:Up(), 90)

                    p = p + a:Forward() * -3   
                    p = p + a:Right() * 2      
                    p = p + a:Up() * -5        

                    self.ClientWM:SetPos(p)
                    self.ClientWM:SetAngles(a)
                    self.ClientWM:DrawModel()
                end
            end
        else
            self:DrawModel()
        end
    end
end

function SWEP:PrimaryAttack()

local owner = self:GetOwner()

if IsValid(owner) then
   local v = owner:GetViewModel()
	if IsValid(v) then
self:EmitSound("chips/eating.wav")
self:Remove()

    if SERVER then
        local ply = self.Owner
        local currentHealth = ply:Health()
        
        -- Heals 25 health and allows health to go past 100 up to 200 max
        local newHealth = currentHealth + 2
        if newHealth > 200 then newHealth = 200 end
        
        ply:SetHealth(newHealth)
        
        -- Play a sound or add a delay here if you want
        self:SetNextPrimaryFire(CurTime() + 1)
    end

end
end

end

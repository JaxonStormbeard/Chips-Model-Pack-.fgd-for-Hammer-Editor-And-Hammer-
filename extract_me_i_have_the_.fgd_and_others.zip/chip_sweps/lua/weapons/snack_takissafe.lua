SWEP.PrintName = "Takis (Safe)"
SWEP.Category = "Chips"
SWEP.ViewModel = Model("models/chipbags/takis/takis.mdl")
SWEP.WorldModel = Model("models/chipbags/takis/takis.mdl")
SWEP.Spawnable = true

SWEP.Primary.Delay = 1
SWEP.Primary.Damage    = 0

SWEP.Author = "JaxonStormbeard"
SWEP.Instructions = "Tastes good!"

SWEP.Primary.Ammo = 0
SWEP.Secondary.Ammo = 0

list.Set("ContentCategoryIcons", "Chips", "icon16/chips.png")

if CLIENT then
    SWEP.WepSelectIcon = surface.GetTextureID("vgui/hud/chips_inv")
end




function SWEP:GetViewModelPosition(pos, ang)

local forward = 15
local right = 12
local up = -9

pos = pos + ang:Forward() * forward + ang:Right() * right + ang:Up() * up
ang:RotateAroundAxis(ang:Up(), 140)
return pos, ang

end

if CLIENT then

killicon.Add("snack_talkis", "killicons/snack_talkis.png", Color(255, 255, 255, 255))

    SWEP.ClientWM = nil

    function SWEP:DrawWorldModel()
        local owner = self:GetOwner()
        
        if IsValid(owner) then
            if not IsValid(self.ClientWM) then
                self.ClientWM = ClientsideModel("models/chipbags/takis/takis.mdl", RENDERGROUP_OPAQUE)
                self.ClientWM:SetNoDraw(true)
            end

            local boneIndex = owner:LookupBone("ValveBiped.Bip01_R_Hand")
            if boneIndex then
                local matrix = owner:GetBoneMatrix(boneIndex)
                if matrix then
                    local p = matrix:GetTranslation()
                    local a = matrix:GetAngles()

                    a:RotateAroundAxis(a:Forward(), 180) 
                    a:RotateAroundAxis(a:Up(), 90)

                    p = p + a:Forward() * -3   
                    p = p + a:Right() * 2      
                    p = p + a:Up() * -5        

                    self.ClientWM:SetPos(p)
                    self.ClientWM:SetAngles(a)
                    self.ClientWM:DrawModel()
                end
            end
        else
            self:DrawModel()
        end
    end
end

function SWEP:PrimaryAttack()
    -- Set the cooldown timer
    self:SetNextPrimaryFire(CurTime() + self.Primary.Delay)

    -- Play a viewmodel animation (e.g., pulling a trigger or injecting)
    self:SendWeaponAnim(ACT_VM_PRIMARYATTACK)

    -- CRITICAL: Damage must strictly be calculated and dealt on the server
    if CLIENT then return end

    local owner = self:GetOwner()

    -- Double-check that the owner exists and is alive
    if IsValid(owner) and owner:Alive() then
        
        -- Create the official damage blueprint object
        local dmgInfo = DamageInfo()
        
        dmgInfo:SetDamage(self.Primary.Damage)       -- Assign self-damage amount
        dmgInfo:SetAttacker(self)                  -- The user is their own attacker
        dmgInfo:SetInflictor(self)                   -- This specific SWEP caused it
        dmgInfo:SetDamageType(DMG_NERVEGAS)          -- Using nervegas/poison bypasses armor
        dmgInfo:SetDamageForce(Vector(0, 0, 0))      -- No physical knockback needed

        -- Apply the damage directly to the person holding the gun
        owner:TakeDamageInfo(dmgInfo)

        -- Play a custom sound effect (flesh hit, grunt, or syringe sound)
        owner:EmitSound("Ambient.ElectricalZap")
	self:Remove()
	self:EmitSound("chips/eating.wav")
    end
end
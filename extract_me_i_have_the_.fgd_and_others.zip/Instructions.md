put the .fgd in C:\\Program Files (x86)\\Steam\\steamapps\\common\\GarrysMod\\bin



put the chip_sweps folder in you're addons folder

